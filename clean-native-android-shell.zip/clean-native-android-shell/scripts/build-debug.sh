#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
BASE_DIR="${BASE_DIR:-/opt/clean-native-android-shell}"
export ANDROID_HOME="${ANDROID_HOME:-$BASE_DIR/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$BASE_DIR/gradle-cache}"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

cd "$PROJECT_DIR"

if [ ! -f "gradlew" ]; then
  if ! command -v gradle >/dev/null 2>&1; then
    echo "gradle command not found. Install Gradle 9.5.1 or run: sdk install gradle 9.5.1" >&2
    exit 1
  fi
  gradle wrapper --gradle-version=9.5.1
fi

./gradlew --no-daemon clean assembleDebug
mkdir -p "$BASE_DIR/output"
cp app/build/outputs/apk/debug/app-debug.apk "$BASE_DIR/output/clean-native-shell-debug.apk"
echo "APK: $BASE_DIR/output/clean-native-shell-debug.apk"

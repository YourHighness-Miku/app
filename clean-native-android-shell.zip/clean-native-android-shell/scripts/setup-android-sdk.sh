#!/usr/bin/env bash
set -euo pipefail

# Clean server layout example:
# /opt/clean-native-android-shell/
# ├── project/
# ├── android-sdk/
# ├── gradle-cache/
# ├── output/
# └── logs/

BASE_DIR="${BASE_DIR:-/opt/clean-native-android-shell}"
ANDROID_HOME="${ANDROID_HOME:-$BASE_DIR/android-sdk}"
CMDLINE_TOOLS_VERSION="${CMDLINE_TOOLS_VERSION:-latest}"
CMDLINE_TOOLS_ZIP="${CMDLINE_TOOLS_ZIP:-https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip}"

mkdir -p "$BASE_DIR" "$ANDROID_HOME/cmdline-tools" "$BASE_DIR/output" "$BASE_DIR/logs" "$BASE_DIR/gradle-cache"

if ! command -v unzip >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y unzip curl ca-certificates openjdk-17-jdk
fi

if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  tmp_zip="/tmp/android-commandline-tools.zip"
  curl -L "$CMDLINE_TOOLS_ZIP" -o "$tmp_zip"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest" /tmp/cmdline-tools
  unzip -q "$tmp_zip" -d /tmp/cmdline-tools
  mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
  mv /tmp/cmdline-tools/cmdline-tools/* "$ANDROID_HOME/cmdline-tools/latest/"
fi

export ANDROID_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null
sdkmanager \
  "platform-tools" \
  "platforms;android-36.1" \
  "build-tools;36.1.0"

echo "Android SDK ready: $ANDROID_HOME"

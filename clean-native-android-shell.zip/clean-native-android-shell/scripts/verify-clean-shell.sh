#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"

for forbidden in flutter react-native uni-app webview cordova capacitor ionic; do
  if grep -Rni --exclude-dir=.gradle --exclude-dir=build --exclude-dir=docs --exclude='README.md' --exclude='verify-clean-shell.sh' "$forbidden" "$ROOT_DIR" >/tmp/clean-shell-hit 2>/dev/null; then
    echo "Forbidden keyword found: $forbidden" >&2
    cat /tmp/clean-shell-hit >&2
    exit 1
  fi
done

required=(
  "$ROOT_DIR/settings.gradle.kts"
  "$ROOT_DIR/build.gradle.kts"
  "$ROOT_DIR/gradle/libs.versions.toml"
  "$ROOT_DIR/app/build.gradle.kts"
  "$ROOT_DIR/app/src/main/AndroidManifest.xml"
  "$ROOT_DIR/app/src/main/kotlin/com/yunyaoxia/androidshell/MainActivity.kt"
)
for f in "${required[@]}"; do
  [ -f "$f" ] || { echo "Missing: $f" >&2; exit 1; }
done

grep -q 'agp = "9.2.0"' "$ROOT_DIR/gradle/libs.versions.toml"
grep -q 'composeBom = "2026.06.00"' "$ROOT_DIR/gradle/libs.versions.toml"
grep -q 'kotlin-gradle-plugin:2.4.0' "$ROOT_DIR/build.gradle.kts"

echo "Clean shell verification passed."

package com.yunyaoxia.androidshell

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NativeShellEntry()
        }
    }
}

@Composable
private fun NativeShellEntry() {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            // Intentionally blank.
            // This is only a clean native Android shell, not a designed UI.
            Box(modifier = Modifier.fillMaxSize())
        }
    }
}

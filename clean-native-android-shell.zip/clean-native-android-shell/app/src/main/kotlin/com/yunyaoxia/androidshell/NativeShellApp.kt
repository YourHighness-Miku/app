package com.yunyaoxia.androidshell

import android.app.Application

/**
 * Clean native Android shell application entry.
 * Keep this class empty until real initialization is required.
 */
class NativeShellApp : Application()

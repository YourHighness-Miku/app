plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.yunyaoxia.androidshell"

    // Latest Android 16 QPR2 SDK: API 36.1.
    // Requires SDK package: platforms;android-36.1
    compileSdk {
        version = release(36) {
            it.minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.yunyaoxia.androidshell"

        // No old-device compatibility target, per requirement.
        minSdk {
            version = release(28)
        }

        targetSdk {
            version = release(36) {
                it.minorApiLevel = 1
            }
        }

        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        compose = true
        buildConfig = false
        aidl = false
        renderScript = false
        resValues = false
        shaders = false
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*"
            )
        }
    }

    sourceSets.named("main") {
        // Explicit Kotlin source directory for AGP 9 built-in Kotlin.
        kotlin.directories += "src/main/kotlin"
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)

    debugImplementation(libs.androidx.compose.ui.tooling)
}

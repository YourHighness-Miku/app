# 轻量服务器构建命令

推荐路径：

```bash
/opt/clean-native-android-shell/
├── project/        # 本工程源码
├── android-sdk/    # Android SDK
├── gradle-cache/   # Gradle 缓存
├── output/         # APK 输出
└── logs/           # 日志
```

部署：

```bash
sudo mkdir -p /opt/clean-native-android-shell/project
sudo chown -R $USER:$USER /opt/clean-native-android-shell
cd /opt/clean-native-android-shell/project
# 把 zip 解压到这里
```

安装 Android SDK：

```bash
cd /opt/clean-native-android-shell/project
bash scripts/setup-android-sdk.sh
```

生成 Debug APK：

```bash
cd /opt/clean-native-android-shell/project
bash scripts/build-debug.sh
```

生成未签名 Release APK：

```bash
cd /opt/clean-native-android-shell/project
bash scripts/build-release.sh
```

输出位置：

```bash
/opt/clean-native-android-shell/output/
```

注意：本工程不包含签名文件。正式发布前需要你自己的 keystore。

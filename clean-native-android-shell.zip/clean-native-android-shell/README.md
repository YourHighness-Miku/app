# Clean Native Android Shell

这是一个干净的 Kotlin + Jetpack Compose 原生 Android 空壳工程。

## 本阶段明确不做

- 不做 UI 设计
- 不做主题
- 不做毛玻璃
- 不做图片素材
- 不做动画
- 不做业务功能
- 不做跨平台
- 不做 WebView 套壳

## 当前锁定版本

- Android Gradle Plugin: 9.2.0
- Gradle Wrapper target: 9.5.1
- Kotlin Gradle Plugin runtime: 2.4.0
- Compose BOM: 2026.06.00
- Activity Compose: 1.13.0
- Core KTX: 1.18.0
- compileSdk: Android 16 QPR2 API 36.1
- targetSdk: Android 16 QPR2 API 36.1
- minSdk: 28
- JDK: 17

## 目录说明

```text
app/src/main/kotlin/com/yunyaoxia/androidshell/
├── MainActivity.kt       # Compose 空白入口
├── NativeShellApp.kt     # Application 空入口
├── core/                 # 预留：公共能力
├── data/                 # 预留：数据层
├── domain/               # 预留：业务域层
├── service/              # 预留：后台服务
└── ui/                   # 预留：UI 层
```

## 构建

见：`docs/SERVER_COMMANDS.md`

## 重要说明

此包是工程源码骨架，不包含 Android SDK、Gradle Wrapper JAR、签名证书、APK 成品。
第一次在服务器构建时，脚本会生成 Gradle Wrapper 并下载依赖。

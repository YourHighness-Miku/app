// Top-level build file for a clean native Android shell.
// AGP 9+ uses built-in Kotlin support, so the app module does NOT apply org.jetbrains.kotlin.android.

buildscript {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    dependencies {
        // Force latest Kotlin Gradle Plugin runtime for AGP built-in Kotlin.
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.0")
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
}
